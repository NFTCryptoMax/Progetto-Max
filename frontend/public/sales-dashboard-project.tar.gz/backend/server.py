from fastapi import FastAPI, APIRouter, HTTPException
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional
import uuid
from datetime import datetime, date
from enum import Enum

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Enums for validation
class OfferStatus(str, Enum):
    ROUND_1 = "Round 1"
    ROUND_2 = "Round 2"
    ROUND_3 = "Round 3"
    ROUND_4 = "Round 4"
    BAFO = "BAFO"
    WON = "Won"
    LOST = "Lost"

class PriorityLevel(str, Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"

# Define Models
class Offer(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    item: str
    customer: str
    offer_name: str
    status: OfferStatus
    start_date: date
    expiry_date: date
    deal_value: float
    priority: PriorityLevel
    assigned_sales_rep: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class OfferCreate(BaseModel):
    item: str
    customer: str
    offer_name: str
    status: OfferStatus = OfferStatus.ROUND_1
    start_date: date
    expiry_date: date
    deal_value: float
    priority: PriorityLevel
    assigned_sales_rep: str

class OfferUpdate(BaseModel):
    item: Optional[str] = None
    customer: Optional[str] = None
    offer_name: Optional[str] = None
    status: Optional[OfferStatus] = None
    start_date: Optional[date] = None
    expiry_date: Optional[date] = None
    deal_value: Optional[float] = None
    priority: Optional[PriorityLevel] = None
    assigned_sales_rep: Optional[str] = None

# Routes
@api_router.get("/")
async def root():
    return {"message": "Sales Dashboard API"}

@api_router.post("/offers", response_model=Offer)
async def create_offer(offer_data: OfferCreate):
    offer_dict = offer_data.dict()
    offer_dict['start_date'] = offer_dict['start_date'].isoformat()
    offer_dict['expiry_date'] = offer_dict['expiry_date'].isoformat()
    
    offer_obj = Offer(**offer_dict)
    offer_dict = offer_obj.dict()
    offer_dict['start_date'] = offer_dict['start_date'].isoformat()
    offer_dict['expiry_date'] = offer_dict['expiry_date'].isoformat()
    
    await db.offers.insert_one(offer_dict)
    return offer_obj

@api_router.get("/offers", response_model=List[Offer])
async def get_offers(
    status: Optional[str] = None,
    priority: Optional[str] = None,
    customer: Optional[str] = None
):
    query = {}
    if status:
        query["status"] = status
    if priority:
        query["priority"] = priority
    if customer:
        query["customer"] = customer
    
    offers = await db.offers.find(query).to_list(1000)
    
    for offer in offers:
        if isinstance(offer.get('start_date'), str):
            offer['start_date'] = datetime.fromisoformat(offer['start_date']).date()
        if isinstance(offer.get('expiry_date'), str):
            offer['expiry_date'] = datetime.fromisoformat(offer['expiry_date']).date()
    
    return [Offer(**offer) for offer in offers]

@api_router.get("/offers/{offer_id}", response_model=Offer)
async def get_offer(offer_id: str):
    offer = await db.offers.find_one({"id": offer_id})
    if not offer:
        raise HTTPException(status_code=404, detail="Offer not found")
    
    if isinstance(offer.get('start_date'), str):
        offer['start_date'] = datetime.fromisoformat(offer['start_date']).date()
    if isinstance(offer.get('expiry_date'), str):
        offer['expiry_date'] = datetime.fromisoformat(offer['expiry_date']).date()
    
    return Offer(**offer)

@api_router.put("/offers/{offer_id}", response_model=Offer)
async def update_offer(offer_id: str, offer_update: OfferUpdate):
    update_data = {k: v for k, v in offer_update.dict().items() if v is not None}
    
    if 'start_date' in update_data:
        update_data['start_date'] = update_data['start_date'].isoformat()
    if 'expiry_date' in update_data:
        update_data['expiry_date'] = update_data['expiry_date'].isoformat()
    
    update_data['updated_at'] = datetime.utcnow()
    
    result = await db.offers.update_one({"id": offer_id}, {"$set": update_data})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Offer not found")
    
    updated_offer = await db.offers.find_one({"id": offer_id})
    
    if isinstance(updated_offer.get('start_date'), str):
        updated_offer['start_date'] = datetime.fromisoformat(updated_offer['start_date']).date()
    if isinstance(updated_offer.get('expiry_date'), str):
        updated_offer['expiry_date'] = datetime.fromisoformat(updated_offer['expiry_date']).date()
    
    return Offer(**updated_offer)

@api_router.delete("/offers/{offer_id}")
async def delete_offer(offer_id: str):
    result = await db.offers.delete_one({"id": offer_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Offer not found")
    return {"message": "Offer deleted successfully"}

# Get unique filter values
@api_router.get("/offers/filters/customers")
async def get_customers():
    customers = await db.offers.distinct("customer")
    return {"customers": customers}

@api_router.get("/offers/filters/sales-reps")
async def get_sales_reps():
    sales_reps = await db.offers.distinct("assigned_sales_rep")
    return {"sales_reps": sales_reps}

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()