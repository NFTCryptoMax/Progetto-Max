#!/usr/bin/env python3
import requests
import json
import uuid
from datetime import datetime, timedelta
import time
import sys

# Get the backend URL from the frontend .env file
BACKEND_URL = "https://ba6f6a3b-cf53-4162-a4c0-831b84c52a1a.preview.emergentagent.com"
API_URL = f"{BACKEND_URL}/api"

print(f"Testing backend at URL: {API_URL}")

# Test data
test_offer = {
    "item": "Enterprise Software License",
    "customer": "Acme Corp",
    "offer_name": "Q1 2024 Software Deal",
    "status": "Round 1",
    "start_date": "2024-06-01",
    "expiry_date": "2024-07-15",
    "deal_value": 125000.50,
    "priority": "High",
    "assigned_sales_rep": "John Smith"
}

# Additional test data for filtering tests
test_offer2 = {
    "item": "Cloud Storage Solution",
    "customer": "TechGiant Inc",
    "offer_name": "Annual Cloud Storage Contract",
    "status": "Round 2",
    "start_date": "2024-05-15",
    "expiry_date": "2024-06-30",
    "deal_value": 85000.00,
    "priority": "Medium",
    "assigned_sales_rep": "Sarah Johnson"
}

test_offer3 = {
    "item": "Security Consulting Package",
    "customer": "Acme Corp",
    "offer_name": "Security Assessment",
    "status": "Won",
    "start_date": "2024-04-01",
    "expiry_date": "2024-05-15",
    "deal_value": 45000.00,
    "priority": "Low",
    "assigned_sales_rep": "John Smith"
}

# Helper functions
def print_separator():
    print("\n" + "="*80 + "\n")

def print_response(response, message=""):
    print(f"{message} Status Code: {response.status_code}")
    try:
        print(json.dumps(response.json(), indent=2))
    except:
        print(response.text)

# Test functions
def test_api_health():
    print_separator()
    print("Testing API Health Check (GET /api/)")
    
    try:
        response = requests.get(f"{API_URL}/")
        print_response(response, "API Health Check Response:")
        
        assert response.status_code == 200, f"Expected status code 200, got {response.status_code}"
        assert "message" in response.json(), "Response should contain 'message' field"
        
        print("✅ API Health Check Test Passed")
        return True
    except Exception as e:
        print(f"❌ API Health Check Test Failed: {str(e)}")
        return False

def test_create_offer():
    print_separator()
    print("Testing Create Offer (POST /api/offers)")
    
    try:
        response = requests.post(f"{API_URL}/offers", json=test_offer)
        print_response(response, "Create Offer Response:")
        
        assert response.status_code == 200, f"Expected status code 200, got {response.status_code}"
        
        # Validate response fields
        data = response.json()
        assert "id" in data, "Response should contain 'id' field"
        assert data["item"] == test_offer["item"], f"Expected item {test_offer['item']}, got {data['item']}"
        assert data["customer"] == test_offer["customer"], f"Expected customer {test_offer['customer']}, got {data['customer']}"
        assert data["offer_name"] == test_offer["offer_name"], f"Expected offer_name {test_offer['offer_name']}, got {data['offer_name']}"
        assert data["status"] == test_offer["status"], f"Expected status {test_offer['status']}, got {data['status']}"
        assert data["deal_value"] == test_offer["deal_value"], f"Expected deal_value {test_offer['deal_value']}, got {data['deal_value']}"
        assert data["priority"] == test_offer["priority"], f"Expected priority {test_offer['priority']}, got {data['priority']}"
        assert data["assigned_sales_rep"] == test_offer["assigned_sales_rep"], f"Expected assigned_sales_rep {test_offer['assigned_sales_rep']}, got {data['assigned_sales_rep']}"
        
        # Save the ID for later tests
        offer_id = data["id"]
        print(f"Created offer with ID: {offer_id}")
        
        print("✅ Create Offer Test Passed")
        return offer_id
    except Exception as e:
        print(f"❌ Create Offer Test Failed: {str(e)}")
        return None

def test_get_all_offers():
    print_separator()
    print("Testing Get All Offers (GET /api/offers)")
    
    try:
        response = requests.get(f"{API_URL}/offers")
        print_response(response, "Get All Offers Response:")
        
        assert response.status_code == 200, f"Expected status code 200, got {response.status_code}"
        
        # Validate response structure
        data = response.json()
        assert isinstance(data, list), "Response should be a list of offers"
        
        if len(data) > 0:
            # Check structure of first offer
            first_offer = data[0]
            assert "id" in first_offer, "Offer should contain 'id' field"
            assert "item" in first_offer, "Offer should contain 'item' field"
            assert "customer" in first_offer, "Offer should contain 'customer' field"
            assert "offer_name" in first_offer, "Offer should contain 'offer_name' field"
            assert "status" in first_offer, "Offer should contain 'status' field"
            assert "start_date" in first_offer, "Offer should contain 'start_date' field"
            assert "expiry_date" in first_offer, "Offer should contain 'expiry_date' field"
            assert "deal_value" in first_offer, "Offer should contain 'deal_value' field"
            assert "priority" in first_offer, "Offer should contain 'priority' field"
            assert "assigned_sales_rep" in first_offer, "Offer should contain 'assigned_sales_rep' field"
        
        print(f"Found {len(data)} offers")
        print("✅ Get All Offers Test Passed")
        return True
    except Exception as e:
        print(f"❌ Get All Offers Test Failed: {str(e)}")
        return False

def test_get_offer_by_id(offer_id):
    print_separator()
    print(f"Testing Get Offer by ID (GET /api/offers/{offer_id})")
    
    try:
        response = requests.get(f"{API_URL}/offers/{offer_id}")
        print_response(response, "Get Offer by ID Response:")
        
        assert response.status_code == 200, f"Expected status code 200, got {response.status_code}"
        
        # Validate response fields
        data = response.json()
        assert data["id"] == offer_id, f"Expected id {offer_id}, got {data['id']}"
        assert "item" in data, "Response should contain 'item' field"
        assert "customer" in data, "Response should contain 'customer' field"
        assert "offer_name" in data, "Response should contain 'offer_name' field"
        assert "status" in data, "Response should contain 'status' field"
        assert "start_date" in data, "Response should contain 'start_date' field"
        assert "expiry_date" in data, "Response should contain 'expiry_date' field"
        assert "deal_value" in data, "Response should contain 'deal_value' field"
        assert "priority" in data, "Response should contain 'priority' field"
        assert "assigned_sales_rep" in data, "Response should contain 'assigned_sales_rep' field"
        
        print("✅ Get Offer by ID Test Passed")
        return True
    except Exception as e:
        print(f"❌ Get Offer by ID Test Failed: {str(e)}")
        return False

def test_update_offer(offer_id):
    print_separator()
    print(f"Testing Update Offer (PUT /api/offers/{offer_id})")
    
    update_data = {
        "status": "Round 2",
        "priority": "Medium",
        "deal_value": 130000.00
    }
    
    try:
        response = requests.put(f"{API_URL}/offers/{offer_id}", json=update_data)
        print_response(response, "Update Offer Response:")
        
        assert response.status_code == 200, f"Expected status code 200, got {response.status_code}"
        
        # Validate response fields
        data = response.json()
        assert data["id"] == offer_id, f"Expected id {offer_id}, got {data['id']}"
        assert data["status"] == update_data["status"], f"Expected status {update_data['status']}, got {data['status']}"
        assert data["priority"] == update_data["priority"], f"Expected priority {update_data['priority']}, got {data['priority']}"
        assert data["deal_value"] == update_data["deal_value"], f"Expected deal_value {update_data['deal_value']}, got {data['deal_value']}"
        
        print("✅ Update Offer Test Passed")
        return True
    except Exception as e:
        print(f"❌ Update Offer Test Failed: {str(e)}")
        return False

def test_delete_offer(offer_id):
    print_separator()
    print(f"Testing Delete Offer (DELETE /api/offers/{offer_id})")
    
    try:
        response = requests.delete(f"{API_URL}/offers/{offer_id}")
        print_response(response, "Delete Offer Response:")
        
        assert response.status_code == 200, f"Expected status code 200, got {response.status_code}"
        assert "message" in response.json(), "Response should contain 'message' field"
        
        # Verify the offer is actually deleted
        verify_response = requests.get(f"{API_URL}/offers/{offer_id}")
        assert verify_response.status_code == 404, f"Expected status code 404 after deletion, got {verify_response.status_code}"
        
        print("✅ Delete Offer Test Passed")
        return True
    except Exception as e:
        print(f"❌ Delete Offer Test Failed: {str(e)}")
        return False

def test_filtering():
    print_separator()
    print("Testing Filtering Functionality")
    
    # Create additional test offers for filtering
    offer_ids = []
    try:
        # Create first test offer
        response1 = requests.post(f"{API_URL}/offers", json=test_offer)
        assert response1.status_code == 200
        offer_ids.append(response1.json()["id"])
        
        # Create second test offer
        response2 = requests.post(f"{API_URL}/offers", json=test_offer2)
        assert response2.status_code == 200
        offer_ids.append(response2.json()["id"])
        
        # Create third test offer
        response3 = requests.post(f"{API_URL}/offers", json=test_offer3)
        assert response3.status_code == 200
        offer_ids.append(response3.json()["id"])
        
        print(f"Created {len(offer_ids)} test offers for filtering tests")
        
        # Test filter by status
        print("\nTesting filter by status (Round 1)")
        status_response = requests.get(f"{API_URL}/offers?status=Round 1")
        print_response(status_response, "Filter by Status Response:")
        assert status_response.status_code == 200
        status_data = status_response.json()
        assert all(offer["status"] == "Round 1" for offer in status_data), "All offers should have status 'Round 1'"
        print(f"Found {len(status_data)} offers with status 'Round 1'")
        
        # Test filter by priority
        print("\nTesting filter by priority (Medium)")
        priority_response = requests.get(f"{API_URL}/offers?priority=Medium")
        print_response(priority_response, "Filter by Priority Response:")
        assert priority_response.status_code == 200
        priority_data = priority_response.json()
        assert all(offer["priority"] == "Medium" for offer in priority_data), "All offers should have priority 'Medium'"
        print(f"Found {len(priority_data)} offers with priority 'Medium'")
        
        # Test filter by customer
        print("\nTesting filter by customer (Acme Corp)")
        customer_response = requests.get(f"{API_URL}/offers?customer=Acme Corp")
        print_response(customer_response, "Filter by Customer Response:")
        assert customer_response.status_code == 200
        customer_data = customer_response.json()
        assert all(offer["customer"] == "Acme Corp" for offer in customer_data), "All offers should have customer 'Acme Corp'"
        print(f"Found {len(customer_data)} offers with customer 'Acme Corp'")
        
        # Test combined filters
        print("\nTesting combined filters (Acme Corp + Won status)")
        combined_response = requests.get(f"{API_URL}/offers?customer=Acme Corp&status=Won")
        print_response(combined_response, "Combined Filters Response:")
        assert combined_response.status_code == 200
        combined_data = combined_response.json()
        assert all(offer["customer"] == "Acme Corp" and offer["status"] == "Won" for offer in combined_data), "All offers should have customer 'Acme Corp' and status 'Won'"
        print(f"Found {len(combined_data)} offers with customer 'Acme Corp' and status 'Won'")
        
        print("✅ Filtering Tests Passed")
        return offer_ids
    except Exception as e:
        print(f"❌ Filtering Tests Failed: {str(e)}")
        return offer_ids

def test_filter_helpers():
    print_separator()
    print("Testing Filter Helper Endpoints")
    
    try:
        # Test customers endpoint
        print("\nTesting GET /api/offers/filters/customers")
        customers_response = requests.get(f"{API_URL}/offers/filters/customers")
        print_response(customers_response, "Customers Filter Response:")
        assert customers_response.status_code == 200
        customers_data = customers_response.json()
        assert "customers" in customers_data, "Response should contain 'customers' field"
        assert isinstance(customers_data["customers"], list), "'customers' should be a list"
        print(f"Found {len(customers_data['customers'])} unique customers")
        
        # Test sales reps endpoint
        print("\nTesting GET /api/offers/filters/sales-reps")
        sales_reps_response = requests.get(f"{API_URL}/offers/filters/sales-reps")
        print_response(sales_reps_response, "Sales Reps Filter Response:")
        assert sales_reps_response.status_code == 200
        sales_reps_data = sales_reps_response.json()
        assert "sales_reps" in sales_reps_data, "Response should contain 'sales_reps' field"
        assert isinstance(sales_reps_data["sales_reps"], list), "'sales_reps' should be a list"
        print(f"Found {len(sales_reps_data['sales_reps'])} unique sales reps")
        
        print("✅ Filter Helper Endpoints Tests Passed")
        return True
    except Exception as e:
        print(f"❌ Filter Helper Endpoints Tests Failed: {str(e)}")
        return False

def cleanup_test_data(offer_ids):
    print_separator()
    print("Cleaning up test data...")
    
    success = True
    for offer_id in offer_ids:
        try:
            response = requests.delete(f"{API_URL}/offers/{offer_id}")
            if response.status_code == 200:
                print(f"Successfully deleted offer with ID: {offer_id}")
            else:
                print(f"Failed to delete offer with ID: {offer_id}, status code: {response.status_code}")
                success = False
        except Exception as e:
            print(f"Error deleting offer with ID: {offer_id}, error: {str(e)}")
            success = False
    
    if success:
        print("✅ All test data cleaned up successfully")
    else:
        print("⚠️ Some test data could not be cleaned up")
    
    return success

def run_all_tests():
    print("\n" + "="*30 + " SALES DASHBOARD API TESTS " + "="*30 + "\n")
    print(f"Testing API at: {API_URL}")
    
    test_results = {}
    
    # Basic API health check
    test_results["api_health"] = test_api_health()
    
    # CRUD operations
    offer_id = test_create_offer()
    test_results["create_offer"] = offer_id is not None
    
    if offer_id:
        test_results["get_all_offers"] = test_get_all_offers()
        test_results["get_offer_by_id"] = test_get_offer_by_id(offer_id)
        test_results["update_offer"] = test_update_offer(offer_id)
        test_results["delete_offer"] = test_delete_offer(offer_id)
    else:
        test_results["get_all_offers"] = False
        test_results["get_offer_by_id"] = False
        test_results["update_offer"] = False
        test_results["delete_offer"] = False
    
    # Filtering tests
    filter_offer_ids = test_filtering()
    test_results["filtering"] = len(filter_offer_ids) > 0
    
    # Filter helper endpoints
    test_results["filter_helpers"] = test_filter_helpers()
    
    # Cleanup
    if filter_offer_ids:
        cleanup_test_data(filter_offer_ids)
    
    # Summary
    print("\n" + "="*30 + " TEST SUMMARY " + "="*30)
    all_passed = True
    for test_name, result in test_results.items():
        status = "✅ PASSED" if result else "❌ FAILED"
        if not result:
            all_passed = False
        print(f"{test_name}: {status}")
    
    if all_passed:
        print("\n🎉 ALL TESTS PASSED! The Sales Dashboard API is working correctly.")
        return 0
    else:
        print("\n⚠️ SOME TESTS FAILED. Please check the logs above for details.")
        return 1

if __name__ == "__main__":
    sys.exit(run_all_tests())